module.exports = class Exemple {
    constructor(exemple) {
        this.exemple = exemple
    }
}